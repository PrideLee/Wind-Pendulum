#include "stm32f10x.h"

void TIM1_Config(uint16_t Period,uint16_t Prescaler);
void TIM5_Config(uint16_t Period,uint16_t Prescaler);


