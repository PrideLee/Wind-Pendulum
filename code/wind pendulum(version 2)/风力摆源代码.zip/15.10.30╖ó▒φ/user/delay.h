#ifndef __DELAY_H
#define __DELAY_H

void DelayInit(void);
void delayus(unsigned int us);
void delayms(unsigned int ms);
void Software_Delay(unsigned int sec);

#endif
